name = "checkoutsdk"
from checkoutsdk.config import *

