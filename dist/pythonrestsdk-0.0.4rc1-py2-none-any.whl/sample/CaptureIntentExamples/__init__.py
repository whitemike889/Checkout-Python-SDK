from sample.CaptureIntentExamples import *
from sample.CaptureIntentExamples import *
from sample.CaptureIntentExamples import *
